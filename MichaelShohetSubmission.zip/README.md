Octopus Energy Submission.

Created with Create-React-App.

Redux for state management in the Item-Container Component.

Local state in Suggestions Component.

Full functionality sans storage and API.

Use yarn to install dependencies.
