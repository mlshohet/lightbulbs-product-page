const CartActionTypes = {
	TOGGLE_SPECS_HIDDEN: 'TOGGLE_SPECS_HIDDEN'
}

export default CartActionTypes;