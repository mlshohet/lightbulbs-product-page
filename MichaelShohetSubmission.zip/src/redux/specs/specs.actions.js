import CartActionTypes from './specs.types';

export const toggleSpecsHidden = () => ({
	type: CartActionTypes.TOGGLE_SPECS_HIDDEN
});

