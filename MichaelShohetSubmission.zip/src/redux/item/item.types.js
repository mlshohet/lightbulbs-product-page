const ItemActionTypes = {
	INCREASE_QUANTITY: 'INCREASE_QUANTITY',
	DECREASE_QUANTITY: 'DECREASE_QUANTITY'
}

export default ItemActionTypes;