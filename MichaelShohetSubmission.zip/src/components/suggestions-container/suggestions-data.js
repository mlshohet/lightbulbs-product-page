	const SUGGESTIONS_DATA = [
				{
				  	index: 0,
				    title: 'Different Item 1',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 25.99
				  },
				{
				  	index: 1,
				    title: 'Different Item 2',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 7.99
				  },
				  {
				  	index: 2,
				    title: 'Different Item 3',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 4.89
				  },
				  {
				  	index: 3,
				    title: 'Different Item 4',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 233.99
				  },
				  {
				  	index: 4,
				    title: 'Different Item 5',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 14.99
				  },
				  {
				  	index: 5,
				    title: 'Different Item 6',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 9.99
				  },
				  {
				  	index: 6,
				    title: 'Different Item 7',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 14.99
				  },
				  {
				  	index: 7,
				    title: 'Different Item 8',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 9.99
				  },
				  {
				  	index: 8,
				    title: 'Different Item 9',
				    imageUrl: 'https://www.washingtonian.com/wp-content/uploads/2014/12/20141204.energylightbulb-635.jpg',
				    price: 45.99
				  },
			];


export default SUGGESTIONS_DATA;